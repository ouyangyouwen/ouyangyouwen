package com.it.ouyanghouse;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;

import static org.junit.jupiter.api.Assertions.*;

class StringRemoveTest {
    private StringRemove stringRemove=new StringRemove();
    @Test
    void implementation() {
        String implementation = stringRemove.Implementation();
        Assert.assertEquals("uu",implementation);
    }
}