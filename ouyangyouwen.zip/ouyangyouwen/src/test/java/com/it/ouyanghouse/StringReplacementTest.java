package com.it.ouyanghouse;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StringReplacementTest {
    private StringReplacement stringReplacement=new StringReplacement();

    @Test
    void replaceString() {
        String replaceString = stringReplacement.replaceString();
        Assert.assertEquals("uu",replaceString);
    }
}