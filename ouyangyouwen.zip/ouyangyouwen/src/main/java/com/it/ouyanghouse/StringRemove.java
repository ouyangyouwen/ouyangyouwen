package com.it.ouyanghouse;

public class StringRemove {
    public  String Implementation() {
        String input = "uaabcccbbadddu";

        return comString(input);

    }

    private  String comString(String input) {
        //创建循环条件t，当字符串找不到三个相同字母时结束循环
        int t = 1;

        while (t <= 1) {
            input = compressString(input);
            int cishu = 1;
            int cishu0 = 0;
            for (int i = 0; i < input.length() - 1; i++) {
                if (input.charAt(i) == input.charAt(i + 1)) {
                    cishu++;
                    if (cishu>2){
                        cishu0++;
                        break;
                    }
                }else {
                    cishu=1;
                    cishu0=0;
                }
            }
            if (cishu0==0){
                t++;
            }
        }
        System.out.println("最终结果为:"+ input);
        return input;
    }

    public  String compressString(String input) {
        StringBuilder compressed = new StringBuilder();
        int count = 1;
        for (int i = 0; i < input.length() - 1; i++) {
            if (input.charAt(i) == input.charAt(i + 1)) {
                count++;
            } else {
                if (count < 3) {
                    for (int j = 0; j < count; j++) {
                        compressed.append(input.charAt(i));
                    }
                }
                count = 1;
            }

        }
        // 处理最后一个字符
        if (count < 3) {
            for (int j = 0; j < count; j++) {
                compressed.append(input.charAt(input.length() - 1));
            }
        }


        return compressed.toString();
    }
}
